KIE EAP Integration
===================